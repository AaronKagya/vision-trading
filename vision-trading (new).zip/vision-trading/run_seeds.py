"""Repeat the SAME configuration with several seeds and report mean +/- sd.
Seeds are repeats, not new configurations, so they do not change --extra-trials.

python run_seeds.py --data data/BTCUSDT_15m.csv --epochs 10 --seeds 0 1 2 3 4
(Already ran seed 0 into results/? Copy that folder to results_seed0 and it will be skipped.)
Any other options (e.g. --encoder, --horizon) are passed straight to src.run_experiments."""
import argparse, json, os, subprocess, sys
import numpy as np

ap = argparse.ArgumentParser(); ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
a, rest = ap.parse_known_args()
dirs = []
for s in a.seeds:
    d = f"results_seed{s}"; dirs.append(d)
    if os.path.exists(os.path.join(d, "metrics.json")):
        print(f"seed {s}: found {d}, skipping"); continue
    print(f"=== seed {s} ===", flush=True)
    subprocess.run([sys.executable, "-m", "src.run_experiments", *rest, "--seed", str(s), "--out", d], check=True)

R = [json.load(open(os.path.join(d, "metrics.json"))) for d in dirs]
models = list(R[0]["models"]); out = {"seeds": a.seeds, "models": {}}
print(f"\nMean +/- sd over {len(R)} seeds")
print(f"{'model':13s}{'accuracy %':>16s}{'AUC':>14s}{'net Sharpe':>16s}")
for m in models:
    acc = np.array([r["models"][m]["accuracy"] for r in R]) * 100
    auc = np.array([r["models"][m]["auc"] for r in R]); sh = np.array([r["models"][m]["sharpe_net"] for r in R])
    out["models"][m] = {"acc_mean": acc.mean(), "acc_sd": acc.std(ddof=1) if len(acc) > 1 else 0.0, "auc_mean": auc.mean(),
                        "auc_sd": auc.std(ddof=1) if len(auc) > 1 else 0.0, "sharpe_mean": sh.mean(), "per_seed_acc": acc.tolist()}
    sd = lambda x: x.std(ddof=1) if len(x) > 1 else 0.0
    print(f"{m:13s}{acc.mean():10.2f} +/-{sd(acc):4.2f}{auc.mean():9.3f} +/-{sd(auc):.3f}{sh.mean():10.2f} +/-{sd(sh):.2f}")
for m in ["cnn_static", "wm_nolatent", "wm"]:
    wins = sum(r["models"][m]["accuracy"] > r["models"]["lstm_ohlc"]["accuracy"] for r in R)
    sig = sum(r["vs_lstm"][m]["significant"] and r["vs_lstm"][m]["acc_diff_vs_lstm"] > 0 for r in R)
    out["models"][m]["seeds_beating_lstm"] = int(wins); out["models"][m]["seeds_significantly_beating_lstm"] = int(sig)
    print(f"{m}: more accurate than the LSTM in {wins}/{len(R)} seeds; significantly better in {sig}/{len(R)}")
os.makedirs("results_seeds", exist_ok=True); json.dump(out, open("results_seeds/summary.json", "w"), indent=2)
print("saved results_seeds/summary.json")
