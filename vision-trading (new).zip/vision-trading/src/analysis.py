"""Extra analysis from results/preds.npz:
  1. accuracy by market volatility (low / mid / high tercile)
  2. accuracy by time block (is the result stable across the test period?)
  3. paired comparison among the visual models themselves
python -m src.analysis [--results results]     -> results/analysis.json + analysis.html"""
import argparse, base64, io, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from src.data import load_candles, synthetic
from src.features import first_valid_index
from src import metrics as X

SHOW = ["persistence", "lstm_ohlc", "cnn_static", "wm_nolatent", "wm"]
NAME = {"persistence": "Persistence", "lstm_ohlc": "LSTM (numbers)", "cnn_static": "Chart CNN", "wm_nolatent": "CNN+GRU", "wm": "World model"}
COL = {"persistence": "#94a3b8", "lstm_ohlc": "#f59e0b", "cnn_static": "#38bdf8", "wm_nolatent": "#22d3ee", "wm": "#34d399"}


def acc_ci(p, y, idx):
    pr = (p[idx] >= 0.5) == y[idx]
    lo, hi = X.block_bootstrap(lambda i: float(pr[i].mean()), len(idx), block=min(50, max(len(idx) // 5, 5)), B=500)
    return float(pr.mean()), lo, hi


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--results", default="results"); a = ap.parse_args()
    res = json.load(open(os.path.join(a.results, "metrics.json"))); d = np.load(os.path.join(a.results, "preds.npz"))
    cfg = res["config"]
    df = synthetic(cfg["n_synth"], "planted" if cfg["data"].endswith("planted") else "null", cfg["seed"]) if cfg["data"].startswith("synthetic") else load_candles(cfg["data"])
    t = d["t_idx"]; y = d["y"]; P = {m: d[f"p_{m}"] for m in SHOW}
    # trailing volatility known at time t: std of the last 32 one-candle log returns
    lr = np.log(df["close"]).diff().values
    vol = np.array([np.nanstd(lr[k - 31:k + 1]) for k in t])
    q1, q2 = np.quantile(vol, [1 / 3, 2 / 3]); grp = np.digitize(vol, [q1, q2])        # 0 low, 1 mid, 2 high
    out = {"volatility": {}, "time_blocks": {}, "visual_pairs": {}}
    for g, gname in enumerate(["low", "mid", "high"]):
        idx = np.where(grp == g)[0]; out["volatility"][gname] = {"n": int(len(idx)), "up_rate": float(y[idx].mean())}
        for m in SHOW: out["volatility"][gname][m] = dict(zip(["acc", "lo", "hi"], acc_ci(P[m], y, idx)))
    blocks = np.array_split(np.arange(len(y)), 4)
    for b, idx in enumerate(blocks):
        out["time_blocks"][f"block{b + 1}"] = {m: float(((P[m][idx] >= 0.5) == y[idx]).mean()) for m in SHOW}
    for m1, m2 in [("wm", "wm_nolatent"), ("wm", "cnn_static"), ("wm_nolatent", "cnn_static")]:
        dd = lambda i: float(((P[m1][i] >= .5) == y[i]).mean() - ((P[m2][i] >= .5) == y[i]).mean())
        lo, hi = X.block_bootstrap(dd, len(y), seed=2)
        out["visual_pairs"][f"{m1} - {m2}"] = {"diff": dd(np.arange(len(y))), "ci": [lo, hi], "significant": bool(lo > 0 or hi < 0)}
    json.dump(out, open(os.path.join(a.results, "analysis.json"), "w"), indent=2)
    # ---- print
    print("Accuracy % by volatility tercile")
    for gname, v in out["volatility"].items():
        print(f"  {gname:5s} (n={v['n']})  " + "  ".join(f"{NAME[m]} {v[m]['acc']*100:.1f}" for m in SHOW))
    print("Accuracy % by time block"); [print(f"  {k}: " + "  ".join(f"{NAME[m]} {v[m]*100:.1f}" for m in SHOW)) for k, v in out["time_blocks"].items()]
    print("Visual models vs each other"); [print(f"  {k}: {v['diff']*100:+.2f} pts, CI [{v['ci'][0]*100:+.2f}, {v['ci'][1]*100:+.2f}] {'significant' if v['significant'] else 'not significant'}") for k, v in out["visual_pairs"].items()]
    # ---- figure + html
    f, ax = plt.subplots(figsize=(7.5, 3.8), facecolor="#0f172a"); ax.set_facecolor("#0f172a"); w = 0.16
    for j, m in enumerate(SHOW):
        xs = np.arange(3) + (j - 2) * w; acc = [out["volatility"][g][m]["acc"] for g in ["low", "mid", "high"]]
        err = [[out["volatility"][g][m]["acc"] - out["volatility"][g][m]["lo"] for g in ["low", "mid", "high"]], [out["volatility"][g][m]["hi"] - out["volatility"][g][m]["acc"] for g in ["low", "mid", "high"]]]
        ax.bar(xs, acc, w, color=COL[m], label=NAME[m]); ax.errorbar(xs, acc, yerr=err, fmt="none", ecolor="#e2e8f0", lw=.8, capsize=2)
    ax.axhline(0.5, color="#f87171", ls="--", lw=1); ax.set_xticks(range(3)); ax.set_xticklabels(["Low volatility", "Mid volatility", "High volatility"], color="#e2e8f0")
    ax.set_ylim(0.4, max(0.62, max(v[m]["hi"] for v in [out["volatility"][g] for g in ["low", "mid", "high"]] for m in SHOW) + .02))
    ax.tick_params(colors="#e2e8f0"); [s.set_color("#334155") for s in ax.spines.values()]; ax.set_title("Direction accuracy by market volatility (95% CI)", color="#e2e8f0", fontsize=10)
    ax.legend(fontsize=7, ncol=5, facecolor="#0f172a", labelcolor="#e2e8f0", edgecolor="#334155", loc="upper center")
    b = io.BytesIO(); f.savefig(b, format="png", dpi=130, bbox_inches="tight", facecolor="#0f172a"); img = base64.b64encode(b.getvalue()).decode(); plt.close(f)
    rows = "".join(f"<tr><td>{k}</td><td>{v['diff']*100:+.2f}</td><td>[{v['ci'][0]*100:+.2f}, {v['ci'][1]*100:+.2f}]</td><td>{'yes' if v['significant'] else 'no'}</td></tr>" for k, v in out["visual_pairs"].items())
    html = f"""<!doctype html><meta charset=utf-8><title>Extra analysis</title><body style="background:#0f172a;color:#e2e8f0;font:15px system-ui;max-width:900px;margin:auto;padding:24px">
<h2 style="color:#34d399">Where does the visual model win or lose?</h2><img src="data:image/png;base64,{img}" style="max-width:100%;border-radius:10px">
<h3>Visual models compared with each other (paired block bootstrap)</h3><table cellpadding=6 style="border-collapse:collapse"><tr><th align=left>Pair</th><th align=left>Accuracy diff (points)</th><th align=left>95% CI</th><th align=left>Significant</th></tr>{rows}</table>
<p style="color:#94a3b8">Volatility = std of the last 32 candle returns, known at prediction time. Terciles are descriptive splits made after the run; do not tune on them.</p></body>"""
    open(os.path.join(a.results, "analysis.html"), "w", encoding="utf-8").write(html); print("wrote", os.path.join(a.results, "analysis.html"))


if __name__ == "__main__":
    main()
