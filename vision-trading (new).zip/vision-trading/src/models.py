"""Encoders, world model, LSTM baseline, and the training/prediction routines."""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

LATENT = 64
ENC_OPTS = {"vit_res": 224}   # set from run_experiments (--vit-res)
DEV = torch.device("cuda" if torch.cuda.is_available() else "cpu")   # uses the GPU automatically (Colab, lab PC)


class CNNEncoder(nn.Module):
    def __init__(self, out=LATENT):
        super().__init__()
        def blk(i, o): return nn.Sequential(nn.Conv2d(i, o, 3, padding=1), nn.BatchNorm2d(o), nn.ReLU(), nn.MaxPool2d(2))
        self.net = nn.Sequential(blk(3, 16), blk(16, 32), blk(32, 64), blk(64, 64))   # 64 -> 4
        self.fc = nn.Linear(64 * 4 * 4, out)

    def forward(self, x):
        return self.fc(self.net(x).flatten(1))


class TorchvisionEncoder(nn.Module):
    """ResNet18 (optionally ImageNet-pretrained). Needs torchvision."""
    def __init__(self, pretrained=False, out=LATENT):
        super().__init__()
        import torchvision
        w = torchvision.models.ResNet18_Weights.DEFAULT if pretrained else None
        m = torchvision.models.resnet18(weights=w); m.fc = nn.Identity()
        self.m, self.fc = m, nn.Linear(512, out)

    def forward(self, x):
        return self.fc(self.m(x))


class ViTEncoder(nn.Module):
    """Vision Transformer (tiny). Needs timm. Images are resized to 224."""
    def __init__(self, pretrained=False, out=LATENT):
        super().__init__()
        import timm
        self.res = ENC_OPTS["vit_res"]          # 224 = standard; 112 uses ~4x less memory and time
        self.m = timm.create_model("vit_tiny_patch16_224", pretrained=pretrained, num_classes=0, img_size=self.res)
        self.fc = nn.Linear(self.m.num_features, out)

    def forward(self, x):
        x = F.interpolate(x, size=self.res, mode="bilinear", align_corners=False)
        return self.fc(self.m(x))


def make_encoder(name, pretrained=False):
    if name == "cnn": return CNNEncoder()
    if name == "resnet18": return TorchvisionEncoder(pretrained)
    if name == "vit_tiny": return ViTEncoder(pretrained)
    raise ValueError(name)


class WorldModel(nn.Module):
    """frames t-K+1..t -> latents -> GRU -> (a) predicted latent of frame t+1, (b) P(price up).
    mode: 'static' = single frame, no sequence model (ablation: no world model)
          'wm'     = full world model (direction loss + next-latent loss)
          'wm_nolatent' = same network but trained with the direction loss only (ablation)."""
    def __init__(self, encoder, mode="wm", K=6):
        super().__init__()
        self.enc, self.mode, self.K = encoder, mode, K
        self.ln = nn.LayerNorm(LATENT)
        self.gru = nn.GRU(LATENT, 64, batch_first=True)
        self.pred = nn.Linear(64, LATENT)
        self.head = nn.Sequential(nn.Linear(LATENT if mode == "static" else 64, 32), nn.ReLU(), nn.Linear(32, 1))

    def embed(self, x):                      # x (B,T,3,S,S) float
        B, T = x.shape[:2]
        return self.ln(self.enc(x.flatten(0, 1))).view(B, T, -1)

    def forward(self, x):
        z = self.embed(x)
        if self.mode == "static":
            return self.head(z[:, -1]).squeeze(-1), None, z
        h, _ = self.gru(z[:, : self.K])
        h = h[:, -1]
        return self.head(h).squeeze(-1), self.pred(h), z


class LSTMBaseline(nn.Module):
    def __init__(self, nin=12):
        super().__init__()
        self.lstm = nn.LSTM(nin, 48, batch_first=True)
        self.head = nn.Sequential(nn.Linear(48, 24), nn.ReLU(), nn.Linear(24, 1))

    def forward(self, x):
        h, _ = self.lstm(x)
        return self.head(h[:, -1]).squeeze(-1)


# ------------------------------------------------------------------
def _img(imgs, idx):                          # idx (B,T) -> float tensor
    return torch.from_numpy(imgs[idx]).to(DEV).float().div_(255.0).sub_(0.5)


def fit_world_model(imgs, y, tr, va, mode, K, enc_name, epochs, lr, bs, lam, seed, pretrained=False):
    torch.manual_seed(seed); rng = np.random.default_rng(seed)
    model = WorldModel(make_encoder(enc_name, pretrained), mode, K).to(DEV)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)
    offs = np.arange(-(K - 1), 2) if mode != "static" else np.array([0])
    yt = torch.from_numpy(y.astype(np.float32)).to(DEV)
    best, best_state, bad = 1e9, None, 0
    use_latent = mode == "wm"
    for ep in range(epochs):
        model.train(); perm = rng.permutation(tr)
        for s in range(0, len(perm), bs):
            b = perm[s:s + bs]
            if len(b) < 8: continue
            x = _img(imgs, b[:, None] + offs[None, :])
            logit, zhat, z = model(x)
            loss = F.binary_cross_entropy_with_logits(logit, yt[b])
            if use_latent:
                tgt = z[:, K].detach()
                loss = loss + lam * (1 - F.cosine_similarity(zhat, tgt, dim=-1)).mean()
                loss = loss + 0.1 * F.relu(1.0 - z[:, :K].reshape(-1, LATENT).std(0)).mean()   # anti-collapse
            opt.zero_grad(); loss.backward(); opt.step()
        v = _val_loss(model, imgs, y, va, offs, bs)
        if v < best - 1e-4: best, bad = v, 0; best_state = {k: t.clone() for k, t in model.state_dict().items()}
        else:
            bad += 1
            if bad >= 3: break
    if best_state: model.load_state_dict(best_state)
    return model, offs


@torch.no_grad()
def _val_loss(model, imgs, y, idx, offs, bs):
    model.eval(); tot = 0.0; n = 0
    for s in range(0, len(idx), bs):
        b = idx[s:s + bs]
        logit, _, _ = model(_img(imgs, b[:, None] + offs[None, :]))
        tot += F.binary_cross_entropy_with_logits(logit, torch.from_numpy(y[b].astype(np.float32)).to(DEV), reduction="sum").item(); n += len(b)
    return tot / max(n, 1)


@torch.no_grad()
def predict_world_model(model, offs, imgs, idx, bs=256):
    model.eval(); p, zs = [], []
    for s in range(0, len(idx), bs):
        b = idx[s:s + bs]
        logit, _, z = model(_img(imgs, b[:, None] + offs[None, :]))
        p.append(torch.sigmoid(logit).cpu().numpy()); zs.append(z[:, model.K - 1 if model.mode != "static" else 0].cpu().numpy())
    z = np.concatenate(zs)
    return np.concatenate(p), float(z.std(0).mean())      # prob(up), latent spread (collapse check)


def fit_predict_lstm(num, y, tr, va, te, epochs, lr, bs, seed):
    torch.manual_seed(seed); rng = np.random.default_rng(seed)
    sd = num[tr].reshape(-1, num.shape[-1]).std(0) + 1e-9
    X = torch.from_numpy(num / sd).float().to(DEV); yt = torch.from_numpy(y.astype(np.float32)).to(DEV)
    m = LSTMBaseline(num.shape[-1]).to(DEV); opt = torch.optim.Adam(m.parameters(), lr=lr, weight_decay=1e-4)
    best, best_state, bad = 1e9, None, 0
    for ep in range(epochs):
        m.train(); perm = rng.permutation(tr)
        for s in range(0, len(perm), bs):
            b = perm[s:s + bs]
            loss = F.binary_cross_entropy_with_logits(m(X[b]), yt[b]); opt.zero_grad(); loss.backward(); opt.step()
        m.eval()
        with torch.no_grad():
            v = F.binary_cross_entropy_with_logits(m(X[va]), yt[va]).item()
        if v < best - 1e-4: best, bad = v, 0; best_state = {k: t.clone() for k, t in m.state_dict().items()}
        else:
            bad += 1
            if bad >= 3: break
    if best_state: m.load_state_dict(best_state)
    m.eval()
    with torch.no_grad():
        return torch.sigmoid(m(X[te])).cpu().numpy()
