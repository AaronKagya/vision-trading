"""Run: python -m tests.test_no_lookahead   (must print PASS before you trust any result)"""
import numpy as np
from src.data import synthetic
from src.features import panels, render


def test():
    df = synthetic(2500, "null", seed=1)
    t_idx, pan = panels(df, 32)
    imgs = render(pan, 64)
    k = 1200; t_star = t_idx[k]
    df2 = df.copy()
    for col in ["open", "high", "low", "close"]:
        df2.loc[t_star + 1:, col] = df2.loc[t_star + 1:, col] * 3.7
    t2, pan2 = panels(df2, 32)
    imgs2 = render(pan2, 64)
    assert np.array_equal(imgs[k], imgs2[k]), "LOOK-AHEAD: image changed when future candles changed"
    t3, pan3 = panels(df.iloc[: t_star + 1].reset_index(drop=True), 32)
    assert np.array_equal(render(pan3, 64)[-1], imgs[k]), "LOOK-AHEAD: truncated history differs"
    assert imgs[k].max() == 255 and (imgs[k] > 0).mean() > 0.02
    print("PASS: no look-ahead in chart rendering")


if __name__ == "__main__":
    test()
