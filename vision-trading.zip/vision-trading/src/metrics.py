"""Forecast, calibration, and overfitting-aware trading statistics."""
import numpy as np
from scipy import stats
from sklearn.metrics import roc_auc_score

EULER = 0.5772156649


def forecast_metrics(p, y):
    pred = p >= 0.5
    acc = float((pred == y).mean())
    brier = float(((p - y) ** 2).mean())
    try: auc = float(roc_auc_score(y, p))
    except ValueError: auc = float("nan")
    return {"accuracy": acc, "brier": brier, "auc": auc, "ece": ece(p, y)}


def ece(p, y, bins=10):
    edges = np.linspace(0, 1, bins + 1); tot = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (p >= lo) & ((p < hi) if hi < 1 else (p <= hi))
        if m.any(): tot += m.mean() * abs(p[m].mean() - y[m].mean())
    return float(tot)


def strategy_returns(p, fwd, cost=0.0005, stride=1):
    """Long if p>=0.5 else short; one non-overlapping trade every `stride` samples; cost per unit position change."""
    p, fwd = p[::stride], fwd[::stride]
    pos = np.where(p >= 0.5, 1.0, -1.0)
    turn = np.abs(np.diff(np.concatenate([[0.0], pos])))
    return pos * fwd - cost * turn


def sharpe(r, periods_per_year):
    sd = r.std(ddof=1)
    return float(r.mean() / sd * np.sqrt(periods_per_year)) if sd > 0 else 0.0


def psr(r, sr_star=0.0):
    """Probabilistic Sharpe ratio (Bailey & Lopez de Prado): P(true SR > sr_star). Per-period SR."""
    T = len(r); sr = r.mean() / (r.std(ddof=1) + 1e-12)
    sk, ku = stats.skew(r), stats.kurtosis(r, fisher=False)
    den = np.sqrt(max(1 - sk * sr + (ku - 1) / 4 * sr ** 2, 1e-9))
    return float(stats.norm.cdf((sr - sr_star) * np.sqrt(T - 1) / den))


def deflated_sharpe(r, trial_srs, n_trials):
    """DSR: PSR against the expected maximum Sharpe of n_trials independent tries (per-period SRs)."""
    n = max(int(n_trials), 2); v = float(np.var(trial_srs, ddof=1)) if len(trial_srs) > 1 else 0.0
    sr_max = np.sqrt(v) * ((1 - EULER) * stats.norm.ppf(1 - 1 / n) + EULER * stats.norm.ppf(1 - 1 / (n * np.e)))
    return psr(r, sr_star=sr_max)


def block_bootstrap(stat_fn, n, block=50, B=1000, seed=0):
    """Moving-block bootstrap CI for stat_fn(index_array)."""
    rng = np.random.default_rng(seed); nb = int(np.ceil(n / block)); out = []
    for _ in range(B):
        starts = rng.integers(0, max(n - block, 1), nb)
        idx = np.concatenate([np.arange(s, s + block) for s in starts])[:n]
        out.append(stat_fn(idx))
    return float(np.percentile(out, 2.5)), float(np.percentile(out, 97.5))
