"""Chart rendering with a built-in no-look-ahead design.

Each sample at candle t uses three timeframe 'views' (15m, 1h, 4h when base = 15m).
View k, candle j is built ONLY from base candles with index <= t:
    end_j = t - (W-1-j) * f_k ;  candle = aggregate of base[end_j - f_k + 1 .. end_j]
so the newest candle of every view ends exactly at t. The three views become the three
image channels (R=15m, G=1h, B=4h). Prices are scaled per panel, so absolute price level is hidden.
"""
import numpy as np
import pandas as pd

FACTORS = (1, 4, 16)


def _views(df):
    o, h, l, c = (df[k].values.astype(np.float64) for k in ("open", "high", "low", "close"))
    out = []
    for f in FACTORS:
        so = pd.Series(o).shift(f - 1).values
        sh = pd.Series(h).rolling(f).max().values
        sl = pd.Series(l).rolling(f).min().values
        out.append(np.stack([so, sh, sl, c], -1))   # (T,4): open, high, low, close
    return out


def first_valid_index(W):
    return W * max(FACTORS) - 1


def panels(df, W=32):
    """Returns t_idx (N,) and panels (N, 3, W, 4)."""
    views = _views(df)
    t_idx = np.arange(first_valid_index(W), len(df))
    pan = []
    for vi, f in enumerate(FACTORS):
        idx = t_idx[:, None] - (W - 1 - np.arange(W))[None, :] * f
        pan.append(views[vi][idx])
    return t_idx, np.stack(pan, 1)


def render(pan, size=64, chunk=2000):
    """pan (N,3,W,4)->uint8 images (N,3,size,size). Up candle=255 body, down=128 body, wick=90."""
    N, V, W, _ = pan.shape
    px = size // W
    out = np.zeros((N, V, size, size), np.uint8)
    for s in range(0, N, chunk):
        p = pan[s:s + chunk]
        hi = p[..., 1].max(-1, keepdims=True); lo = p[..., 2].min(-1, keepdims=True)
        rng = np.maximum(hi - lo, 1e-12)
        y = lambda a: np.rint((hi - a) / rng * (size - 1)).astype(np.int16)   # row 0 = top = high
        yO, yH, yL, yC = y(p[..., 0]), y(p[..., 1]), y(p[..., 2]), y(p[..., 3])
        rows = np.arange(size)[None, None, :]
        img = np.zeros((p.shape[0], V, size, size), np.uint8)
        for j in range(W):
            x0 = j * px
            top = np.minimum(yO[..., j], yC[..., j])[..., None]; bot = np.maximum(yO[..., j], yC[..., j])[..., None]
            wick = (rows >= yH[..., j][..., None]) & (rows <= yL[..., j][..., None])
            body = (rows >= top) & (rows <= bot)
            up = (p[..., j, 3] >= p[..., j, 0])[..., None]
            img[..., x0] = np.where(wick, 90, img[..., x0])
            for dx in range(px):
                img[..., x0 + dx] = np.where(body, np.where(up, 255, 128), img[..., x0 + dx])
        out[s:s + chunk] = img
    return out


def numeric_features(pan):
    """Numeric twin of the images (same OHLC, same windows) for the LSTM baseline: (N, W, 12)."""
    c_t = pan[:, 0, -1, 3][:, None, None, None]
    rel = np.log(pan / c_t)                       # (N,3,W,4)
    return rel.transpose(0, 2, 1, 3).reshape(pan.shape[0], pan.shape[2], -1).astype(np.float32)
