"""Walk-forward comparison of baselines vs visual models.

python -m src.run_experiments --data synthetic_planted --epochs 4          # quick pipeline check
python -m src.run_experiments --data data/BTCUSDT_15m.csv --epochs 10       # real run
"""
import argparse, json, os, time
import numpy as np
from sklearn.linear_model import LogisticRegression

from src.data import load_candles, synthetic
from src.features import panels, render, numeric_features, first_valid_index
from src import models as M
from src import metrics as X

MODELS = ["majority", "persistence", "logreg_lags", "lstm_ohlc", "cnn_static", "wm_nolatent", "wm"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="synthetic_planted")
    ap.add_argument("--n-synth", type=int, default=7000)
    ap.add_argument("--window", type=int, default=32)
    ap.add_argument("--img", type=int, default=64)
    ap.add_argument("--horizon", type=int, default=4, help="predict direction h candles ahead")
    ap.add_argument("--K", type=int, default=6, help="frames fed to the world model")
    ap.add_argument("--folds", type=int, default=4)
    ap.add_argument("--epochs", type=int, default=8)
    ap.add_argument("--bs", type=int, default=128)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--lam", type=float, default=0.5, help="weight of the next-latent loss")
    ap.add_argument("--encoder", default="cnn", choices=["cnn", "resnet18", "vit_tiny"])
    ap.add_argument("--pretrained", action="store_true")
    ap.add_argument("--cost", type=float, default=0.0005, help="cost per unit position change (0.0005 = 5 bps)")
    ap.add_argument("--extra-trials", type=int, default=0, help="other configs you tried and discarded (counted for DSR)")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", default="results")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True); t0 = time.time()

    # ---------------- data
    if a.data.startswith("synthetic"):
        kind = "planted" if a.data.endswith("planted") else "null"
        df = synthetic(a.n_synth, kind, a.seed)
    else:
        df = load_candles(a.data)
    t_idx, pan = panels(df, a.window)
    imgs = render(pan, a.img); num = numeric_features(pan)
    close = df["close"].values[t_idx]; h = a.horizon
    n_img = len(imgs)
    fwd = np.full(n_img, np.nan); fwd[:-h] = np.log(close[h:] / close[:-h])
    y = (fwd > 0).astype(np.int64)
    lag_ret = np.full((n_img, 5), 0.0)
    cl = df["close"].values
    for k in range(5):
        lag_ret[:, k] = np.log(cl[t_idx - k] / cl[t_idx - k - 1])
    mom = np.full(n_img, 0.0); mom[h:] = np.log(close[h:] / close[:-h])   # trailing h-candle return (known at t)
    samples = np.arange(a.K - 1, n_img - h)                               # need t+h label and K frames
    n = len(samples); print(f"{len(df)} candles -> {n} samples | up-rate {y[samples].mean():.3f}")

    # ---------------- walk-forward folds (expanding window, with embargo)
    emb = h + a.K
    first_test = int(0.5 * n); edges = np.linspace(first_test, n, a.folds + 1).astype(int)
    probs = {m: [] for m in MODELS}; te_all = []; extras = {"latent_spread": {m: [] for m in ["cnn_static", "wm_nolatent", "wm"]}}
    fold_rows = []
    for f in range(a.folds):
        te = samples[edges[f]:edges[f + 1]]
        tr_end = edges[f] - emb
        va_len = int(0.15 * tr_end); va = samples[tr_end - va_len:tr_end]
        tr = samples[:tr_end - va_len - emb]
        assert tr.max() + h < te.min() and va.max() + h < te.min(), "leakage between train/val and test"
        te_all.append(te); print(f"fold {f}: train {len(tr)} val {len(va)} test {len(te)}")
        probs["majority"].append(np.full(len(te), float(y[tr].mean() >= 0.5)))
        probs["persistence"].append((mom[te] > 0).astype(float))
        lr_ = LogisticRegression(max_iter=300).fit(lag_ret[tr], y[tr]); probs["logreg_lags"].append(lr_.predict_proba(lag_ret[te])[:, 1])
        probs["lstm_ohlc"].append(M.fit_predict_lstm(num, y, tr, va, te, a.epochs, a.lr, a.bs, a.seed))
        for name, mode, lam in [("cnn_static", "static", 0.0), ("wm_nolatent", "wm_nolatent", 0.0), ("wm", "wm", a.lam)]:
            model, offs = M.fit_world_model(imgs, y, tr, va, mode, a.K, a.encoder, a.epochs, a.lr, a.bs, lam, a.seed, a.pretrained)
            p, spread = M.predict_world_model(model, offs, imgs, te)
            probs[name].append(p); extras["latent_spread"][name].append(spread)
        print(f"   done fold {f}  ({time.time() - t0:.0f}s)")
    te = np.concatenate(te_all); P = {m: np.concatenate(v) for m, v in probs.items()}
    yt, ft = y[te], fwd[te]

    # ---------------- metrics
    ppy = 365 * 24 * 4 / h                                  # trades per year (non-overlapping)
    res = {"config": vars(a), "n_test": int(len(te)), "up_rate_test": float(yt.mean()), "models": {}}
    rets = {m: X.strategy_returns(P[m], ft, a.cost, stride=h) for m in MODELS}
    srs = {m: float(rets[m].mean() / (rets[m].std(ddof=1) + 1e-12)) for m in MODELS}
    n_trials = len(MODELS) + a.extra_trials
    trial_srs = np.array(list(srs.values()))
    for m in MODELS:
        fm = X.forecast_metrics(P[m], yt)
        lo, hi = X.block_bootstrap(lambda i, m=m: float(((P[m][i] >= 0.5) == yt[i]).mean()), len(te))
        res["models"][m] = {**fm, "acc_ci": [lo, hi], "sharpe_net": X.sharpe(rets[m], ppy),
                            "psr": X.psr(rets[m]), "dsr": X.deflated_sharpe(rets[m], trial_srs, n_trials),
                            "total_return": float(rets[m].sum()), "n_trades": int(len(rets[m]))}
    for m in ["cnn_static", "wm_nolatent", "wm"]:
        res["models"][m]["latent_spread"] = float(np.mean(extras["latent_spread"][m]))
    # paired comparisons vs the numeric LSTM (the key test of H2)
    comp = {}
    for m in ["cnn_static", "wm_nolatent", "wm", "persistence"]:
        d = lambda i, m=m: float(((P[m][i] >= 0.5) == yt[i]).mean() - ((P["lstm_ohlc"][i] >= 0.5) == yt[i]).mean())
        lo, hi = X.block_bootstrap(d, len(te), seed=1)
        comp[m] = {"acc_diff_vs_lstm": d(np.arange(len(te))), "ci": [lo, hi], "significant": bool(lo > 0 or hi < 0)}
    res["vs_lstm"] = comp; res["n_trials"] = n_trials; res["buy_hold_total_return"] = float(ft[::h].sum())
    json.dump(res, open(os.path.join(a.out, "metrics.json"), "w"), indent=2)
    np.savez_compressed(os.path.join(a.out, "preds.npz"), te=te, y=yt, fwd=ft, t_idx=t_idx[te], **{f"p_{m}": P[m] for m in MODELS})
    np.save(os.path.join(a.out, "sample_imgs.npy"), imgs[te][:: max(len(te) // 12, 1)][:12])
    print(f"\nfinished in {time.time() - t0:.0f}s. Results in {a.out}/. Next: python -m src.report")
    for m in MODELS:
        r = res["models"][m]; print(f"{m:12s} acc {r['accuracy']:.3f} [{r['acc_ci'][0]:.3f},{r['acc_ci'][1]:.3f}]  auc {r['auc']:.3f}  net Sharpe {r['sharpe_net']:.2f}  DSR {r['dsr']:.2f}")


if __name__ == "__main__":
    main()
