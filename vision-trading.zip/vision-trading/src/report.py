"""Builds results/report.html: a single self-contained, shareable results page.
python -m src.report [--results results]"""
import argparse, base64, io, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from src import metrics as X

NAMES = {"majority": "Majority class", "persistence": "Persistence (trend continues)", "logreg_lags": "Logistic regression, 5 lags",
         "lstm_ohlc": "LSTM on OHLC numbers", "cnn_static": "Chart CNN (single frame)",
         "wm_nolatent": "Chart CNN + GRU (no latent loss)", "wm": "Visual world model (full)"}
COL = {"majority": "#6b7280", "persistence": "#94a3b8", "logreg_lags": "#a78bfa", "lstm_ohlc": "#f59e0b",
       "cnn_static": "#38bdf8", "wm_nolatent": "#22d3ee", "wm": "#34d399"}
BG, FG, GRID = "#0f172a", "#e2e8f0", "#334155"


def _fig(w=6.2, h=3.4):
    f, ax = plt.subplots(figsize=(w, h), facecolor=BG); ax.set_facecolor(BG)
    for s in ax.spines.values(): s.set_color(GRID)
    ax.tick_params(colors=FG, labelsize=8); ax.xaxis.label.set_color(FG); ax.yaxis.label.set_color(FG); ax.title.set_color(FG)
    ax.grid(color=GRID, alpha=.5, lw=.5); return f, ax


def _b64(f):
    b = io.BytesIO(); f.savefig(b, format="png", dpi=130, bbox_inches="tight", facecolor=BG); plt.close(f)
    return "data:image/png;base64," + base64.b64encode(b.getvalue()).decode()


def verdict(res):
    c = res["vs_lstm"]; wm, cs = c["wm"], c["cnn_static"]
    acc = res["models"]["wm"]["accuracy"]; dsr = res["models"]["wm"]["dsr"]
    if wm["significant"] and wm["acc_diff_vs_lstm"] > 0:
        head = "The visual world model beat the numeric LSTM out of sample."
        tail = f"Its accuracy was {wm['acc_diff_vs_lstm']*100:+.1f} points better (95% CI {wm['ci'][0]*100:+.1f} to {wm['ci'][1]*100:+.1f})."
    elif wm["significant"]:
        head = "The visual world model did worse than the numeric LSTM."
        tail = f"Difference {wm['acc_diff_vs_lstm']*100:+.1f} points (95% CI {wm['ci'][0]*100:+.1f} to {wm['ci'][1]*100:+.1f})."
    else:
        head = "No reliable difference between the visual world model and the numeric LSTM."
        tail = f"The accuracy gap was {wm['acc_diff_vs_lstm']*100:+.1f} points with a 95% CI of {wm['ci'][0]*100:+.1f} to {wm['ci'][1]*100:+.1f}, which includes zero. This is a valid null result."
    skill = "Trading statistics do not show skill after correcting for the number of models tried." if dsr < 0.95 else "The deflated Sharpe ratio is above 0.95 for the world model; check costs and robustness before claiming anything."
    return head, f"{tail} {skill}"


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--results", default="results"); a = ap.parse_args()
    res = json.load(open(os.path.join(a.results, "metrics.json"))); d = np.load(os.path.join(a.results, "preds.npz"))
    cfg = res["config"]; h = cfg["horizon"]; models = list(res["models"])
    y, fwd = d["y"], d["fwd"]
    # --- accuracy bars with CI
    f, ax = _fig(6.4, 3.6)
    for i, m in enumerate(models):
        r = res["models"][m]; ax.barh(i, r["accuracy"], color=COL[m], alpha=.9)
        ax.errorbar(r["accuracy"], i, xerr=[[r["accuracy"] - r["acc_ci"][0]], [r["acc_ci"][1] - r["accuracy"]]], color=FG, capsize=3, lw=1)
    ax.axvline(0.5, color="#f87171", ls="--", lw=1); ax.set_yticks(range(len(models))); ax.set_yticklabels([NAMES[m] for m in models], color=FG, fontsize=8)
    lo = min(0.45, min(res["models"][m]["acc_ci"][0] for m in models) - .01); ax.set_xlim(lo, max(res["models"][m]["acc_ci"][1] for m in models) + .02)
    ax.set_title("Direction accuracy on unseen periods (95% CI)", fontsize=10); acc_img = _b64(f)
    # --- equity curves
    f, ax = _fig(6.4, 3.6)
    for m in models:
        r = X.strategy_returns(d[f"p_{m}"], fwd, cfg["cost"], stride=h); ax.plot(np.cumsum(r), color=COL[m], lw=2.2 if m == "wm" else 1.1, label=NAMES[m])
    ax.plot(np.cumsum(fwd[::h]), color="#f8fafc", lw=1, ls=":", label="Buy and hold"); ax.set_title(f"Cumulative net log return (costs {cfg['cost']*1e4:.0f} bps)", fontsize=10)
    ax.legend(fontsize=6, facecolor=BG, labelcolor=FG, edgecolor=GRID, ncol=2); eq_img = _b64(f)
    # --- calibration
    f, ax = _fig(4.2, 3.6); ax.plot([0, 1], [0, 1], color="#64748b", ls="--")
    for m in ["lstm_ohlc", "wm"]:
        p = d[f"p_{m}"]; bins = np.linspace(0, 1, 11); xs, ys = [], []
        for lo_, hi_ in zip(bins[:-1], bins[1:]):
            k = (p >= lo_) & (p < hi_ + (1e-9 if hi_ == 1 else 0))
            if k.sum() >= 15: xs.append(p[k].mean()); ys.append(y[k].mean())
        ax.plot(xs, ys, "o-", color=COL[m], label=NAMES[m], ms=4)
    ax.set_xlabel("Predicted P(up)"); ax.set_ylabel("Observed frequency"); ax.set_title("Calibration", fontsize=10); ax.legend(fontsize=7, facecolor=BG, labelcolor=FG, edgecolor=GRID); cal_img = _b64(f)
    # --- sample charts
    sample = np.load(os.path.join(a.results, "sample_imgs.npy")); k = len(sample)
    f, axs = plt.subplots(2, 4, figsize=(8, 4.4), facecolor=BG)
    for i, ax in enumerate(axs.ravel()):
        ax.axis("off")
        if i < k: ax.imshow(sample[i].transpose(1, 2, 0)); ax.set_title(["R=15m  G=1h  B=4h"][0] if i == 0 else "", color=FG, fontsize=7)
    chart_img = _b64(f)
    head, tail = verdict(res)
    rows = ""
    for m in models:
        r = res["models"][m]; star = " class=hl" if m == "wm" else ""
        rows += (f"<tr{star}><td>{NAMES[m]}</td><td>{r['accuracy']*100:.1f}% <small>[{r['acc_ci'][0]*100:.1f}, {r['acc_ci'][1]*100:.1f}]</small></td>"
                 f"<td>{r['auc']:.3f}</td><td>{r['brier']:.4f}</td><td>{r['ece']:.3f}</td><td>{r['sharpe_net']:.2f}</td><td>{r['psr']:.2f}</td><td>{r['dsr']:.2f}</td></tr>")
    crow = "".join(f"<tr><td>{NAMES[m]}</td><td>{v['acc_diff_vs_lstm']*100:+.2f}</td><td>[{v['ci'][0]*100:+.2f}, {v['ci'][1]*100:+.2f}]</td><td>{'yes' if v['significant'] else 'no'}</td></tr>" for m, v in res["vs_lstm"].items())
    spread = res["models"]["wm"].get("latent_spread", 0)
    html = f"""<!doctype html><html lang=en><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>Visual World Models for Trading: Results</title>
<style>
:root{{--bg:#0f172a;--card:#1e293b;--fg:#e2e8f0;--mut:#94a3b8;--acc:#34d399;--line:#334155}}
@media(prefers-color-scheme:light){{:root{{--bg:#f1f5f9;--card:#fff;--fg:#0f172a;--mut:#475569;--acc:#059669;--line:#cbd5e1}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--fg);font:15px/1.5 system-ui,Segoe UI,sans-serif}}
.wrap{{max-width:1050px;margin:auto;padding:28px 18px}}h1{{font-size:1.7rem;margin:0}}h2{{font-size:1.1rem;margin:28px 0 10px;color:var(--acc)}}
.sub{{color:var(--mut);margin:4px 0 18px}}.card{{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px}}
.kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}}.k b{{display:block;font-size:1.5rem}}.k span{{color:var(--mut);font-size:.8rem}}
.verdict{{border-left:5px solid var(--acc);font-size:1.02rem}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:14px}}
img{{max-width:100%;border-radius:10px}}table{{border-collapse:collapse;width:100%;font-size:.85rem}}th,td{{padding:6px 8px;border-bottom:1px solid var(--line);text-align:left}}
th{{color:var(--mut);font-weight:600}}tr.hl td{{background:rgba(52,211,153,.12);font-weight:600}}small{{color:var(--mut)}}.note{{color:var(--mut);font-size:.82rem}}
.scroll{{overflow-x:auto}}</style>
<div class=wrap>
<h1>Do visual world models add information beyond numbers?</h1>
<p class=sub>Walk-forward test on {res['n_test']:,} unseen samples &middot; horizon {h} candles &middot; {cfg['folds']} folds &middot; encoder {cfg['encoder']} &middot; {res['n_trials']} model configurations counted for deflation</p>
<div class="card verdict"><b>{head}</b><br>{tail}</div>
<h2>Headline numbers</h2>
<div class=kpis>
<div class="card k"><b>{res['models']['wm']['accuracy']*100:.1f}%</b><span>World model direction accuracy</span></div>
<div class="card k"><b>{res['models']['lstm_ohlc']['accuracy']*100:.1f}%</b><span>Numeric LSTM accuracy</span></div>
<div class="card k"><b>{res['models']['wm']['dsr']:.2f}</b><span>Deflated Sharpe (needs &gt; 0.95)</span></div>
<div class="card k"><b>{res['models']['wm']['sharpe_net']:.2f}</b><span>Net Sharpe after costs</span></div>
<div class="card k"><b>{spread:.2f}</b><span>Latent spread (near 0 = collapse)</span></div></div>
<h2>Comparison</h2><div class=grid><div class=card><img src="{acc_img}" alt="accuracy"></div><div class=card><img src="{eq_img}" alt="equity"></div></div>
<h2>All models</h2><div class="card scroll"><table><tr><th>Model</th><th>Accuracy [95% CI]</th><th>AUC</th><th>Brier</th><th>ECE</th><th>Net Sharpe</th><th>PSR</th><th>DSR</th></tr>{rows}</table></div>
<h2>Visual models vs the numeric LSTM (paired block bootstrap)</h2><div class="card scroll"><table><tr><th>Model</th><th>Accuracy difference (points)</th><th>95% CI</th><th>Significant</th></tr>{crow}</table></div>
<h2>Calibration and what the model sees</h2><div class=grid><div class=card><img src="{cal_img}" alt="calibration"></div><div class=card><img src="{chart_img}" alt="charts"><p class=note>Each image packs three timeframes into colour channels: red 15-minute, green 1-hour, blue 4-hour candles.</p></div></div>
<h2>How to read this</h2><div class="card note">Chronological walk-forward splits with an embargo of {h + cfg['K']} samples; the rendering is checked to use no future candles. Sharpe ratios use one non-overlapping trade per {h} candles with {cfg['cost']*1e4:.0f} bps cost per position change. PSR is the probability the true Sharpe exceeds zero; DSR also corrects for the {res['n_trials']} configurations tried, so report both and report every configuration you tried. A null result is a valid finding. Data: {cfg['data']}.</div>
</div></html>"""
    out = os.path.join(a.results, "report.html"); open(out, "w", encoding="utf-8").write(html); print("wrote", out)


if __name__ == "__main__":
    main()
