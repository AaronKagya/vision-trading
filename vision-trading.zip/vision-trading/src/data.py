"""Market data: free Binance history download, loading, and a synthetic generator for testing."""
import io, os, urllib.request, zipfile
import numpy as np
import pandas as pd

COLS = ["time", "open", "high", "low", "close", "volume"]


def download_binance(symbol="BTCUSDT", interval="15m", start="2024-01", end="2024-12", out_dir="data"):
    """Download monthly kline zips from data.binance.vision and merge to one CSV.
    Check Binance's terms of use before using the data in a publication."""
    os.makedirs(out_dir, exist_ok=True)
    months = pd.period_range(start, end, freq="M")
    frames = []
    for m in months:
        ym = str(m)
        url = f"https://data.binance.vision/data/spot/monthly/klines/{symbol}/{interval}/{symbol}-{interval}-{ym}.zip"
        try:
            raw = urllib.request.urlopen(url, timeout=60).read()
        except Exception as e:
            print(f"  skip {ym}: {e}")
            continue
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            df = pd.read_csv(z.open(z.namelist()[0]), header=None)
        df = df.iloc[:, :6]; df.columns = COLS
        t = pd.to_numeric(df["time"], errors="coerce")
        if t.iloc[0] > 1e14:        # newer files use microseconds
            t = t // 1000
        df["time"] = pd.to_datetime(t, unit="ms")
        frames.append(df)
        print("  got", ym, len(df))
    if not frames:
        raise RuntimeError("No data downloaded. Check your internet connection and the date range.")
    out = pd.concat(frames).drop_duplicates("time").sort_values("time")
    path = os.path.join(out_dir, f"{symbol}_{interval}.csv")
    out.to_csv(path, index=False)
    print("saved", path, len(out), "candles")
    return path


def load_candles(path):
    df = pd.read_csv(path, parse_dates=["time"]).sort_values("time").drop_duplicates("time")
    df = df.reset_index(drop=True)
    bad = ((df.high < df[["open", "close"]].max(axis=1) - 1e-9) | (df.low > df[["open", "close"]].min(axis=1) + 1e-9)).sum()
    if bad:
        print(f"warning: {bad} candles with inconsistent OHLC")
    d = df.time.diff().dropna()
    gaps = (d != d.mode()[0]).sum()
    if gaps:
        print(f"warning: {gaps} gaps in the time index")
    return df


def synthetic(n=8000, kind="null", seed=0):
    """Synthetic 15-minute candles.
    kind='null'    : random walk with volatility clustering (no learnable signal; expect ~50% accuracy)
    kind='planted' : adds weak momentum on the ~4-hour scale, so a working pipeline should beat 50%."""
    rng = np.random.default_rng(seed)
    vol = np.empty(n); v = 0.002
    for i in range(n):
        v = 0.98 * v + 0.02 * 0.002 + 0.0003 * abs(rng.standard_normal()); vol[i] = v
    r = np.zeros(n)
    for i in range(n):
        eps = vol[i] * rng.standard_normal()
        drift = 0.0
        if kind == "planted" and i > 16:
            drift = 0.12 * vol[i] * np.sign(r[i - 16:i].sum())
        r[i] = drift + eps
    close = 30000 * np.exp(np.cumsum(r))
    open_ = np.concatenate([[30000], close[:-1]])
    spread = np.abs(rng.standard_normal(n)) * vol * close * 0.6
    high = np.maximum(open_, close) + spread
    low = np.minimum(open_, close) - spread
    time = pd.date_range("2024-01-01", periods=n, freq="15min")
    return pd.DataFrame({"time": time, "open": open_, "high": high, "low": low, "close": close,
                         "volume": rng.uniform(1, 10, n)})
