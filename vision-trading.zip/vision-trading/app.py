"""Interactive demo: pick a moment in the unseen test period and see what each model predicted.
streamlit run app.py"""
import json, os
import numpy as np
import streamlit as st
from src.data import load_candles, synthetic
from src.features import panels, render, first_valid_index

st.set_page_config(page_title="Visual World Model Demo", layout="wide")
NAMES = {"majority": "Majority class", "persistence": "Persistence", "logreg_lags": "Logistic regression (5 lags)",
         "lstm_ohlc": "LSTM on OHLC numbers", "cnn_static": "Chart CNN (single frame)",
         "wm_nolatent": "Chart CNN + GRU", "wm": "Visual world model"}

rdir = st.sidebar.text_input("Results folder", "results")
if not os.path.exists(os.path.join(rdir, "metrics.json")):
    st.error("Run `python -m src.run_experiments` first, then reload."); st.stop()


@st.cache_data(show_spinner="Rebuilding charts...")
def load(rdir):
    res = json.load(open(os.path.join(rdir, "metrics.json"))); d = dict(np.load(os.path.join(rdir, "preds.npz")))
    cfg = res["config"]
    if cfg["data"].startswith("synthetic"):
        df = synthetic(cfg["n_synth"], "planted" if cfg["data"].endswith("planted") else "null", cfg["seed"])
    else:
        df = load_candles(cfg["data"])
    t_idx, pan = panels(df, cfg["window"])
    rows = d["t_idx"] - first_valid_index(cfg["window"])
    return res, d, df, render(pan[rows], cfg["img"])


res, d, df, imgs = load(rdir)
h = res["config"]["horizon"]; n = len(d["y"])
st.title("Can a model read a chart?")
st.caption(f"Unseen test period only. Each moment shows the three timeframes the model sees and what every model predicted for the next {h} candles.")
i = st.slider("Moment in the test period", 0, n - 1, n // 2)
c = st.columns([1.2, 1, 1, 1])
c[0].image(imgs[i].transpose(1, 2, 0), caption="Model input (R=15m, G=1h, B=4h)", width=300, clamp=True)
for k, (nm, col) in enumerate(zip(["15-minute", "1-hour", "4-hour"], c[1:])):
    col.image(imgs[i][k], caption=nm, width=200, clamp=True)
t = df.time.iloc[int(d["t_idx"][i])]; up = bool(d["y"][i])
st.subheader(f"{t:%Y-%m-%d %H:%M}  |  actual: {'UP' if up else 'DOWN'}  ({d['fwd'][i]*100:+.2f}%)")
rows = []
for m in NAMES:
    p = float(d[f"p_{m}"][i]); rows.append({"Model": NAMES[m], "P(up)": round(p, 3), "Call": "UP" if p >= .5 else "DOWN", "Correct": "yes" if (p >= .5) == up else "no"})
st.table(rows)
st.markdown("**Overall on the unseen period**")
st.dataframe({NAMES[m]: {"Accuracy": f"{v['accuracy']*100:.1f}%", "AUC": f"{v['auc']:.3f}", "Net Sharpe": f"{v['sharpe_net']:.2f}", "Deflated Sharpe": f"{v['dsr']:.2f}"}
              for m, v in res["models"].items()})
st.info("Research demo on historical data. Not investment advice.")
